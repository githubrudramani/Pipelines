import setuptools
setuptools.setup(
	name ="py_nsolver",
	version="0.0.4",
	author="Dr. Rudramani Pokhrel",
	description="Python package to analyze nanostring nsolver mRNA data",
	packages=["py_nsolver"]
	)